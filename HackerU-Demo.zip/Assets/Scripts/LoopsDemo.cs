using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LoopsDemo : MonoBehaviour
{
    Transform[] arrTransforms;

    // Start is called before the first frame update
    void Start()
    {
        float f = 3.14159123f;
        Debug.Log($"{(int)f}");
       /*
        * Debug.Log("This is a For Loop:");

        for (int i=0; i < 10; i++)
        {
            Debug.Log($"{i * i}");
        }

        arrTransforms = FindObjectsOfType<Transform>();
        

        foreach (Transform t in arrTransforms)
        {

        }
       */
        

    }



}
